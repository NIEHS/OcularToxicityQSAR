#needed for roc.area:
library(AUC)

#qsar_eval() calculates statistics for the prediction results (total, average, st.dev)
#input - 	a full name of a tab-separated file with the header and at least three columns (dataID, OBSERVED, PREDICTED)
#		additional columns can be loaded and used for stratified statistics (see mode)
#output - 	file name to save reported stats, by default: input + .stat
#
#mode - 	0..2 - bootstrap (uses bootf, bootn), >3 - column ID to stratify by
#
#bootf - 	sample fraction for bootstraping (only used if mode < 3), if >= #tot.samples, then done with replacement
#bootn - 	#runs for bootstrapping (only used if mode < 3)
#vbad - 	dummy value (will be treated as N/A) 


#------------------

MAX_N_CLASS<-10
MIN_SZ_CLASS<-2

#Q2_ETC calculates statistics for the continuous predictions
#X - vector of predicted values
#Y - vector of observed values
#X,Y should be of the same length
#
#returns: NULL of any error, otherwise: a vector of the following parameters:
#	n, actual #samples
#	Q2, which is = 1 - RSS/TSS, where RSS is (PRED - OBS)^2
#	Pearson r, inter-class correlation
#	Spearman rho,
#	Kendall tau,
#	ICC, intra-class correlation
#	MAE, mean absolute error
#	RMSE, root mean squared error

Q2_ETC<-function(PRED, OBS)
{
  if (length(PRED) != length(OBS)) return (NA)
  if (any(is.na(OBS))) return (NA)
  if (length(OBS) < 2) return (NA)
  n<-is.na(PRED)
  
  if (any(n)) return (Q2_ETC(PRED[!n], OBS[!n]))
  
  N<-length(OBS)
  av<-mean(OBS)
  AE<-abs(PRED - OBS)
  SE<-AE*AE
  t<-OBS - av	
  
  s<-vector("numeric", 8)
  
  s[1]<- N
  s[2]<- 1 - sum(SE)/sum(t*t)				#Q2
  s[3]<-cor(PRED, OBS, use = "all.obs",  method = "pearson")	
  s[4]<-cor(PRED, OBS, use = "all.obs",  method = "spearman")
  s[5]<-cor(PRED, OBS, use = "all.obs",  method = "kendall")	
  
  pX<-c(PRED, OBS)
  av<-mean(pX)
  t<- pX - av
  
  s[6]<-2*sum((PRED - av)*(OBS - av))/sum(t*t)	#ICC
  s[7]<-mean(AE)
  s[8]<-sqrt(mean(SE))
  
  rm(AE, SE, t, pX, av)
  return (s)
}


auc_bp<-function( x, y )
{#finds best performing cutoff from ROC AUC
  dta <- roc(x, as.factor(y) )
  #plot(dta)
  
  bp <- dta$cutoffs[ which.max(dta$tpr - dta$fpr) ]
  return ( bp )
}

auc_calc<-function( x, y )
{#work-around auc() function in AUC R-Package (seems faulty there)
  dta <- roc(x, as.factor(y) )
  
  n <- length( dta$tpr )
  dx <- dta$fpr - c(0, dta$fpr[-n])
  avy <- dta$tpr + c(0, dta$tpr[-n])
  return ( 0.5*sum( dx*avy ) )
}

#CCR_ETC calculates statistics for the categorical predictions
#X - vector of predicted values
#Y - vector of observed values, should be same length with X
#bps - vector of break-points to assign X values into integer bins (estimated from ROC AUC rounded, if NULL)
#		for n categories bps[] should have size n-1 (one breakpoint per margin, samples that fall on breakpoint are rounded up) or 
#		2(n-1) if 2 breakpoints denote margin's width (sample points inside the margin are then discarded)
#
#RETURNS: NULL of any error, otherwise: a vector of the following parameters:
#	n, total number of samples
#	Ni, 	i-th class size
#	ACCi,	i-th class accuracy 
#			(i cycles through 1..n for n-category data)
#	CCR (correct classification rate, a.k.a. balanced accuracy),
#	Chi^2 (~MCC), 
#	Cohen's kappa, (assumes categories are not order-related)
#	Mutual Information (log2 base), 
#	AUC (for the highest-value category), related to GINI, Wilcox, Mann-Whitney test
# NB( remaining reported values are break-points used)
#TODO: can explore MCA? corresp()


CCR_ETC<-function(PRED, OBS, bps = NULL)
{
  nn <- length(PRED)
  if (nn != length(OBS)) return (NA)
  if (nn < 2) return (NA)
  
  I<-is.na(PRED)
  if (any(I)) return (CCR_ETC(PRED[!I], OBS[!I], bps))
  
  if (any(is.na(OBS))) return (NA)
  
  cat<-sort(unique(OBS))
  ncat<-length(cat)
  
  if (is.null(bps) && (ncat == 2) )
  {
    bps <- auc_bp(PRED, OBS)
    #bps
  }
  
  CPRED<-round(PRED)
  if (!is.null(bps))
  {#classify categories
    nbps<-ncat - 1
    if (length(bps) == nbps)
      for (i in 1:nn)
      {
        CPRED[i]<-cat[ncat]
        for (j in 1:nbps)
          if (bps[j] > PRED[i]) 
          {
            CPRED[i]<- cat[j]
            break;
          }
      }
    
    if (length(bps) == 2*nbps)
      for (i in 1:nn)	
      {
        CPRED[i]<-cat[ncat]
        for (j in 1:nbps)
        {
          if (bps[2*j-1] > PRED[i])
          {
            CPRED[i]<- cat[j]
            break;
          }
          
          if (bps[2*j] > PRED[i])
          {
            CPRED[i]<- NA
            break;
          }
        }
      }
  } #if (!is.null(bps))
  
  I<-!is.na(CPRED)
  if (length(unique(c(cat, CPRED[I]))) != ncat) return (NULL)	#either PRED or bps were invalid
  
  nondegen <- TRUE
  #calculate contingency matrix
  TB<-as.matrix(table(OBS[I], CPRED[I]))
  
  if (dim(TB)[2]<ncat)	
  {
    #degenerative predictions
    nondegen <- FALSE
    TB<-cbind(vector("numeric", ncat), TB)
  }
  
  Nis<-rowSums(TB)
  PNis<-colSums(TB)
  Ntot <- sum(Nis)
  slen <- 2*ncat + 6
  s<-vector("numeric", slen + length(bps))
  
  s[ (slen+1):(slen+length(bps)) ] <- bps
  
  for (i in 1:ncat)
  {
    s[i+1]<-Nis[i]
    s[ncat+1+i]<-(TB[i,i]/Nis[i])
  }
  
  s[1]<-Ntot
  s[2*ncat+2]<-mean(s[(ncat+2):(2*ncat+1)])				#CCR
  
  if (nondegen)
  {  
    s[2*ncat+3]<-chisq.test(TB)$statistic
  }
  else
  {
    s[2*ncat+3]<- -999
  } 
  
  Pe<-sum(PNis*Nis)/Ntot							#probability of agreement by random 
  s[2*ncat+4]<- (sum(diag(TB)) - Pe)/(Ntot-Pe)			#kappa
  s[2*ncat+5]<- 0								#Mutual Information
  for (i in 1:ncat)
    for (j in 1:ncat)
      if (TB[i,j] > 0)
        s[2*ncat+5]<-s[2*ncat+5] + (TB[i,j]/Ntot) * log2(TB[i,j]*Ntot/Nis[i]/PNis[j])
  
  mnP<-min(PRED)
  rP<-max(PRED) - mnP
  HITS<-(OBS == cat[ncat])
  hOBS<-OBS
  hOBS[HITS]<-1
  hOBS[!HITS]<-0
  
  
  s[2*ncat+6]<- auc_calc( PRED, hOBS )
  
  #s[2*ncat+6]<-roc.area( hOBS, (PRED - mnP)/rP )$A	#AUC of ROC-curve
  
  return (s)
}



#----- main interface function
qsar_eval<-function(input, output=NULL, mode=0, bootf=0.8, bootn=1000, vbad=-999)
{
	T<-read.table(input, fill=TRUE, skip=1, row.names=NULL, header=FALSE, comment.char="", quote="", sep="\t", 
na.string = "NA", stringsAsFactors = FALSE)

	n<-dim(T)[1]
	if ( dim(T)[2]< max(mode, 3) ) return (vbad)	
	nact<-length( unique(T[,2]) )
	if (nact < 2) return (vbad)

	if (is.null(output))	output<-paste(input, ".stat", sep="")

	CONT<- ( (nact > MAX_N_CLASS)||(n< MIN_SZ_CLASS*nact) ) 
	
	X<-as.numeric(T[,3])
	Y<-as.numeric(T[,2])
	
	#fix dummy values before the analysis
	I<-(X == vbad)
	X[I]<-NA

	if (mode > 3)
	{
		folds<-T[,mode]
		strata<-unique(folds)
		nruns<-length( strata )
	}
	else
	{
		mode<- 0
		nruns<-bootn
		nsample<-round(bootf*n)
		if (nsample < n) 
			ifrepl<-FALSE
		else
		{
			nsample<-n
			ifrepl<-TRUE
		}
	}

	if (CONT)
	{
		REP<-matrix(0, nruns, 8)
		colnames(REP)<-c('n', 'Q2', 'Pearson r', 'Spearman rho', 'Kendall tau', 'ICC', 'MAE', 'RMSE')
		comm<-paste("#Continuous stats for", input, sep=" ")
	}
	else	
	{
		REP<-matrix(0, nruns, 3*nact+5)
		colnames(REP)<-c( 'n', paste('N(Class', 1:nact, ')', sep=""), paste('Acc(Class', 1:nact, ')', sep=""), 'CCR', 'Chi2', 'CohenKappa', 'MuteInfo', 'AUC', paste0('break-point_', 1:(nact-1)) )
		comm<-paste("#Category stats for", input, sep=" ")
	}

	for (i in 1:nruns)
	{
		if (mode > 3)	
			I<-(folds == strata[i])
		else
			I<-sample.int(n, nsample, ifrepl, NULL)

		if ( CONT )	REP[i,]<-Q2_ETC(X[I], Y[I])	else	REP[i,]<-CCR_ETC(X[I], Y[I])
	}

	#report final stats
	avREP<-apply(REP, 2, mean, na.rm = TRUE)
	sdREP<-apply(REP, 2, sd, na.rm = TRUE)
	if ( CONT )	totREP<-Q2_ETC(X, Y)	else	totREP<-CCR_ETC(X, Y)	
	write.table(cbind(c("tot", "mean", "sd"), round(rbind(totREP, avREP, sdREP), 3)), file=output, quote=FALSE, sep="\t", row.names = FALSE, col.names = c(comm, colnames(REP)), append=FALSE)
	
	if (mode > 3)	#report the folds
		write.table(cbind(paste("Fold", strata, sep=""), round(REP, 3)), file=output, quote=FALSE, sep="\t", row.names = FALSE, col.names = FALSE, append=TRUE)
	
	return (0) #successful completion
}

bin_gap_eval<-function(PRED, OBS, nmax = 100)
#evaluates binary classification performance by using two cut-offs 
#( "< C1" for inactive class, and " >= C2" for active class)
#with a "grayzone" gap [C1, C2) in between;
#at most nmax different cut-offs for each class are explored or less (if there are fewer unique values)
#
# PREDICTED and OBSERVED vectors should be binary and same length
{
  observed <- as.numeric(OBS)
  catgs <- sort( unique(observed) )
  if ( (length(catgs) != 2) || (length(PRED) != length(OBS)) )
  { #not applicable
    return (NULL);
  }
  
  vals <- unique(PRED)
  mnv <- min(vals)
  mxv <- max(vals)
  
  n <- min(nmax, length(vals) )
  Cstep <- (mxv - mnv) / (n + 1)
  
  ns <- length(PRED) #needed for coverage calculations
  C1s <- mnv + Cstep*(1:n)
  
  vCCR <- matrix(0, n, n)
  colnames(vCCR) <- paste0("C1_N", 1:n)
  rownames(vCCR) <- paste0("C2_N", 1:n)
  vCOV <- vCCR
  
  
  for (c1 in 1:n)
  {
    bp1 <- mnv + c1*Cstep
    
    for (c2 in c1:n)
    {
       bp2 <- mnv + c2*Cstep
       
       PA <- observed[ PRED >= bp2 ]
       PI <- observed[ PRED < bp1 ]
       
       TP <- length( PA[ PA == catgs[2] ] )
       TN <- length( PI[ PI == catgs[1] ] )
       FP <- length( PA[ PA == catgs[1] ] )
       FN <- length( PI[ PI == catgs[2] ] )
       
       vCOV[c1, c2] <- (TP + TN + FP + FN) / ns
       if (c2 > c1) vCOV[c2, c1] <- vCOV[c1, c2]
       vCCR[c1, c2] <- 0.5*(TP / (TP + FN) + TN / (TN + FP))
       if (c2 > c1) vCCR[c2, c1] <- vCCR[c1, c2]
    }
  }
  
  list(cutoffs=C1s, coverage=vCOV, balanced_acc=vCCR)
}

#debug
#aa <- read.table("C:\\DATA\\OcuTox\\sets_010219\\preds\\RF_OCU_EPA_IRR_X_MAIN.txt", sep = "\t", header = TRUE)
#ho <- bin_gap_eval(aa$CALC, aa$EXP)
#image(ho$coverage)
#image(ho$balanced_acc)
