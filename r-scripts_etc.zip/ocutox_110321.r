#Ocular Toxicity project scripts 2018 - 2021
library(readxl)
library(reticulate)
library(random)

#odir - project folder that contains all data files, adjust appropriately
odir <- "C:\\Data\\OcuTox"
setwd(odir)

m <- import("mordred")
rdk <- import("rdkit")


#----------------------------------------------------------------------------------------------------
#----------------- preparation of chemical features (Steps 1 - 3)
##----------------

#load SMILES codes for the unique components from the master Excel file
dd <- read_excel("OcuTox_110321_FIN.xlsx", sheet = "DESCR")

#1) SMARTS features
Quat <- rdk$Chem$MolFromSmarts('[#6]-[#7;+;X3]([#6])=,:[#6]') 
Heavy <- rdk$Chem$MolFromSmarts('[Mn,Cr,Cd,Hg,Cs,Sb,Sn,Pb,Os]')
Efiles <- rdk$Chem$MolFromSmarts('[$(OO),$([Al,B;v3]),$([Cl,Br,I][CX4]),$([Cl,Br,I,F]-[Cl,Br,I,F,O]),$(O=[CH,CH2]),$(O=C-[F,I,Cl,Br]),$(O=[C;r6]-[#6;X3]=,:[#6;X3]-[C;r6]=O),$(O=[C;r6]-[C;r6]=O)]')

calc <- m$Calculator(m$descriptors)

ns <- dim(dd)[1]
smhits <- matrix(0, ns, 3)
colnames(smhits) <- c ("Heavy", "Efiles", "Quat")
rownames(smhits) <- dd$CC_ID
for (s in 1:ns)
{

  mol <- rdk$Chem$MolFromSmiles( as.character(dd$CURATED_COMPONENT[s]) )
  if (mol$HasSubstructMatch(Heavy)) smhits[s,1] <- 1
  if (mol$HasSubstructMatch(Efiles)) smhits[s,2] <- 1
  if (mol$HasSubstructMatch(Quat)) smhits[s,3] <- 1
  
}
write.table(smhits, file="smarts_features.txt", sep='\t', quote = FALSE, col.names = TRUE, row.names = TRUE, append = FALSE)


#2) mordred descriptors can be  batch-calculated separately:
#source_python("-m mordred -o hehe2.csv inp.smi") #command line option

#3) pKa, pH, etc descriptors were calculated externally (e.g., ADMET Predictor)


#All the descriptors from Steps 1-3 are then combined into one matrix in  the "DESCR" tab






setwd("C:\\_DATA\\OcuTox\\deliverables\\")
#----------------------------------------------------------------------------------------------------
##---------------- weighting descriptors for 1) mixture-based representation and 2) conventional one, based on main component

#set the master file that should have mapping table (for substances vs components) and a descriptors matrix:
#NB: provide full path to the file, if needed
#xls_file <- "ECHA_PROPS.xlsx"
xls_file <- "OcuTox_110321_FIN.xlsx"    
#normed_file <- "echa1k"
normed_file <- "cas"
#-------------------------
#NB: load a subset of descriptor labels to extract this subset automatically by name:
ll <- read.table("ocutox_dscr_lbl_mod.txt", header = FALSE, comment.char = '')
descriptor_names <- as.character(unlist(ll))

ff <- read_excel(xls_file, sheet = "MAP") 
mm <- ff[,c("CASNUM", "CC_ID", "N", "NATOMS", "MAIN")]
ff <- read_excel(xls_file, sheet = "DESCR")
dd <- as.matrix(ff[,c("CC_ID", descriptor_names)]) #loads a subset of columns with needed descriptors and the component IDs (CC_ID)
rownames(dd) <- paste0("CC", ff$CC_ID)

nmap <- dim(mm)[1]
CAS <- unique(mm$CASNUM)
WTS <- rep(0, nmap)

#iterate over substances as defined by unique ID (CAS) and calculate for substance c its i-th components weights
un <- length(CAS)
for (c in CAS)
{
  i <- mm$CASNUM == c
  compo <- mm$N[i] * mm$NATOMS[i] #n heavy atoms
  WTS[i] <- compo / sum(compo)
}

#write data into temp files for the reality checks:
#write.table(data.frame(mm, WTS), file = "weights.txt", sep='\t', quote = FALSE, col.names = TRUE, row.names = TRUE)
#write.table(dd, file="components_mtx.txt", sep='\t', quote = FALSE, col.names = TRUE, row.names = TRUE)

m <- dim(dd)[2]
fsubst <- matrix(0, un, m)
colnames(fsubst) <- c("CASNUM", descriptor_names)
rownames(fsubst) <- paste0("RN", CAS)

for (ri in 1:un)
{
  i <- mm$CASNUM == CAS[ri]
  compo <- paste0("CC",mm$CC_ID[i])
  if (length(compo) == 1)
  { #single component substance, propagate feature vector as is
    fsubst[ri,] <-  dd[compo,]
  }
  else
  {#weighted sum applied for all features except pH
    pp2 <- dd[compo,]
    for (ci in 3:m) pp2[,ci] <- pp2[,ci] * WTS[i]
    fsubst[ri,3:m] <- apply(pp2[,3:m], 2, sum)
    
    #fix pH
    p1 <- min(pp2[,2])
    p2 <- max(pp2[,2])
    if (p1 > 6) p1 <- p2
    if (p2 < 8) p2 <- p1
    fsubst[ri,2] <- 0.5*(p1+p2)
    fsubst[ri,1] <- max(mm$MAIN[i] * mm$CC_ID[i]) #main component ID
  }
} #ri


write.table(fsubst, file=paste0(normed_file,"_mix.txt"), sep='\t', quote = FALSE, col.names = TRUE, row.names = TRUE)

mains <- paste0("CC",fsubst[1:un,1])
fsubst[1:un,] <-  dd[mains,]
write.table(fsubst, file=paste0(normed_file,"_main.txt"), sep='\t', quote = FALSE, col.names = TRUE, row.names = TRUE)
rm(fsubst)


#----------------------------------------------------------------------------------------------------
#Note: In case of OCUTOXDB, resulting output matrices (e.g., cas_mix.txt and cas_main.txt) 
#       are then joined with content of "DATASETS" tab to form all the datasets used for modeling
#      the dataset file names are "OCU_(EPA|GHS)_(ANY|IRR|CORR)_(HI|LO)_(MAIN|MIX).txt", with variable suffix parts in parentheses
#----------------------------------------------------------------------------------------------------
#
#likewise weighting should be done for the test set, using "ECHA_PROPS.xlsx" file to prepare 
# "echa1k_main.txt" and "echa1k_mix.txt" descriptor files for running model prediction
#----------------------------------------------------------------------------------------------------






# Step 4 - Modeling, resulting models are saved as RDS files
#-------------------------------------------------------------------------------------------------------------------
#-------------------------------------------------------------------------------------------------------------------
#-------------------------------------------------------------------------------------------------------------------
library(caret)
library(randomForest)
library(e1071)
library(glmnet)
library(kernlab)
library(extraTrees) #requires rJava

#NB: adjust path to source files loaded below:
source("qsar_eval.r")
source("xa.r")
source("get_ad.r")

MLmethods <- c("parRF", "svmRadialWeights", "glmnet", "extraTrees")

trn_ctl <- caret::trainControl(method   = "repeatedcv", repeats = 5, number = 5,
                               classProbs      = TRUE, summaryFunction = twoClassSummary,
                               savePredictions = "final", search = "random")

trn_ctl_oob <- caret::trainControl(method   = "oob", number = 3, classProbs      = TRUE,
                                   savePredictions = "final", search = "random")


ModelFit <- function(xx, yy, MLtype, metricType, trControlParams=trn_ctl, ...) 
{
  startTime <- Sys.time()
  print(paste("Starting", MLtype, "at", Sys.time()), quote=FALSE)
  
  fitData <- caret::train(x = xx, y =yy, method = MLtype, metric = metricType, trControl = trControlParams)
  
  endTime <- Sys.time()
  print(paste("Time to run", MLtype))
  print(endTime - startTime)
  
  return(fitData)
}


#also prepare the ECHA test set to run against the models:
ll <- read.table("ocutox_dscr_lbl_mod.txt", header = FALSE, comment.char = '')
descriptor_names <- as.character(unlist(ll)) #this contains filtered list of globally non-redundant descriptors (when checked for entire OCUTOXDB list)

E1K <- read.table("echa1k_mix.txt", sep='\t', quote = '', comment.char = '')[,c(-1)]
E1KC <- read.table("echa1k_main.txt", sep='\t', quote = '', comment.char = '')[,c(-1)]

colnames(E1K) <- descriptor_names
colnames(E1KC) <- descriptor_names


wd <- paste0(odir, "\\sets\\") #adjust to subfolder with datasets
outdir2 <- paste0(wd, "models\\") #this points to the output subfolder where results are saved

setwd(wd)
base1<-list.files(wd, pattern = '^OCU.*MAIN.*txt$', ignore.case = TRUE, full.names = FALSE)
base2<-list.files(wd, pattern = '^OCU.*MIX.*txt$', ignore.case = TRUE, full.names = FALSE)
basen <- c(base1, base2)
basenames <- sub('\\.txt$', '', basen)

#f <- basen[1]
for (xf in 1:length(basen)) #loops through dataset files, additionally renormalizing and removing remaining redundant descriptors per set
{
  f <- basen[xf]
  name <- basenames[xf]
  
  M <- read.table(f, sep = '\t', quote = '', comment.char = '', skip = 1)
  ids <- paste0("RN",M[, 1])
  
  colnames(M) <- c("CASNUM", "ACT", descriptor_names)
  rownames(M) <- ids
  obs <- M[,2]
  lbl <- descriptor_names
  
  #vars should have no NAs but can check
  x <- M[, c(-1,-2)]
  #removing redundancies additionally for each set (will be stored in )
  nx <- dim(x)[1]
  #bb <- nearZeroVar(x, freqCut = 100, uniqueCut = 0.01)
  bb <- nearZeroVar(x, freqCut = nx/5, uniqueCut = 300/nx) #allows ~5 counts for binary features
  
  ivars <- 1:dim(x)[2]
  ivarsc <- ivars[-bb]
  xx <- findCorrelation(cor(x[,-bb]),0.99, exact = FALSE)
  cc <- ivarsc[xx] #fix, was ivars[]
  
  dd <- sort( c(bb, cc ) ) #complete set of indices
  
  cf1 <- coffs(x[,-dd]) #range-scaling
  vv <- renorm(x[,-dd], cf1)
  colnames(vv) <- lbl[-dd]
  rownames(vv) <- ids
  
  fobs <- obs
  fobs[obs == 1] <- "pos"
  fobs[obs == 0] <- "neg"
  fobs <- as.factor(make.names(fobs))
  
  #store original dimensions (LBL, as well as other needed details on data matrix)
  cursetf = list(ACT=fobs, IDS= ids, LBL=lbl, SBX = ivars[-dd], CFG = cf1, MTX = vv)
  
  rm(ivars, ivarsc, vv)
  
  if (xf > length(base1))
  {
    exv <- renorm(E1K[,cursetf$SBX], cursetf$CFG)
  }  else
  {
    exv <- renorm(E1KC[,cursetf$SBX], cursetf$CFG)
  }
  
  #caret models
  #MLmethods <- c("parRF", "svmRadial", "glmnet", "extraTrees") #NB: defined higher up in the code as a global parameter
  for (ML in MLmethods)
  {
    qsr1 <- ModelFit(cursetf$MTX, cursetf$ACT, ML, "ROC")
    pp <- predict(qsr1, exv, type = "prob") #NB: prediction of a test set, can be anything prepared before hand
    
    smp <- sort(unique(qsr1$pred$rowIndex))
    
    z <- lapply(1 : length(smp), function(i) 
    {
      s1 <- qsr1$pred$rowIndex == i
      return (colMeans( qsr1$pred[s1,c("neg", "pos")] ))
    }
    )
    
    pred <- matrix(unlist(z), ncol = 2, byrow = TRUE)
    rm(z)
    
    oo <- data.frame(ID = ids, exp = obs, pred = pred[,2], N = 3) #fixed
    colnames(oo)<-c('dataID', 'EXP', 'CALC', 'N')
    
    #store predictions
    repf<-paste(outdir2, name, '_', ML, '.txt',sep="")
    write.table(oo, file=repf, row.names=FALSE, col.names=TRUE, sep="\t", quote=FALSE, append=FALSE)
    
    echas<-paste(outdir2, "ECHA1K_", name, '_', ML, '.txt',sep="")
    write.table(pp, file=echas, row.names=TRUE, col.names=TRUE, sep="\t", quote=FALSE, append=FALSE)
    
    #store model and related data
    mlobj <- paste(outdir2, name, '_', ML, '.rds', sep="")
    if (ML == "extraTrees")
    {
      .jcache(qsr1$finalModel$jobject) #rJava package needed? not saved properly
    }
    saveRDS( list(QSAR = qsr1, DATA = cursetf), file = mlobj )
    
    
    #print extra stats
    reps <- paste(outdir2, name, '_', ML, '.caret', sep="")
    mxROC <- max(qsr1$results[,"ROC"])
    write.table(qsr1$results[qsr1$results[,"ROC"] == mxROC,], file=reps, row.names=FALSE, col.names=TRUE, sep="\t", quote=FALSE, append=FALSE)
    
    
    #add importance scores
    reps2 <- paste(outdir2, name, '_', ML, '.var', sep="")
    
    vscores<-caret::varImp(qsr1)
    write.table(vscores$importance, file=reps2, row.names=TRUE, col.names=TRUE, sep="\t", quote=FALSE, append=FALSE)
    
  } #for ML
  
  
} #xf
#--------------------------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------




#--------------------------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------
#Step 5. a code piece to run predictions vs saved models:
#--------------------------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------

setwd(odir)
ll <- read.table("ocutox_dscr_lbl_mod.txt", header = FALSE, comment.char = '')
descriptor_names <- as.character(unlist(ll))
#external sets ready
E1K <- read.table("echa1k_mix.txt", sep='\t', quote = '', comment.char = '')[,c(-1)]
#E1K <- read.table("echa1k_main.txt", sep='\t', quote = '', comment.char = '')[,c(-1)]
colnames(E1K) <- descriptor_names


moddir <- paste0(odir,"\\sets\\models\\")  #set to path with rds-files that are model objects

#iterate over models
setwd(moddir)
mm<-list.files(moddir, pattern = '.*_MAIN_.*rds', ignore.case = TRUE, full.names = FALSE)
basemm <- sub('\\.rds$', '', mm)

ext1 <- matrix(-99, dim(E1K)[1], length(basemm))
colnames(ext1) <- basemm
rownames(ext1) <- rownames(E1K)
#m <- 3
for (m in 1:length(mm))
{
  hh <- read.table(paste0(moddir, basemm[m], ".txt"), header = TRUE)
  
  best_bp <- auc_bp( hh$CALC, hh$EXP )
  st <- CCR_ETC( hh$CALC, hh$EXP, best_bp)
  CCR <- st[6]
  AUC <- st[10]
  if ((CCR > 0.55) && (AUC > 0.6)) #consider as acceptable model to use, if cross-validated performance was high
  {
    
    Q <- readRDS(paste0(moddir, mm[m]))  #load model and aux data:     #Q$QSAR and Q$DATA
    subd <- colnames(Q$DATA$MTX)
    
    exv <- renorm(E1K[,subd], Q$DATA$CFG) #normalizes features of test set to match the current QSAR model
    
    pp <- predict(Q$QSAR, exv, type = "prob") #prediction run
    
    bin1 <- pp[,2] > best_bp #compares with optimal break-point of the current model, to classify into a binary call
    
    ext1[!bin1, m] <- 0
    ext1[ bin1, m] <- 1
  }
  
} #m

write.table(ext1, "ECHA_1K_MAIN_PREDS.txt", sep = '\t') #can be rerun likewise for _MIX version
#--------------------------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------




#----------------------------------------------------------------------------------------------------------------
#----------------------------------------------------------------------------------------------------------------
#Misc. tasks: Steps 6.... Calculation and harvesting of results, etc.
#----------------------------------------------------------------------------------------------------------------
#----------------------------------------------------------------------------------------------------------------
#AD estimate for ECHA set
Q <- readRDS("OCU_GHS_ANY_HI_MAIN_parRF.rds") #NOTE: path to the largest modeling dataset model to use as the global applicability domain (GAD)
dim(Q$DATA$MTX)

ll <- read.table("ocutox_dscr_lbl_mod.txt", header = FALSE, comment.char = '')
descriptor_names <- as.character(unlist(ll))
E1K <- read.table("echa1k_main.txt", sep='\t', quote = '', comment.char = '')[,c(-1)]
colnames(E1K) <- descriptor_names
exv <- renorm(E1K[,Q$DATA$SBX], Q$DATA$CFG)
ECHA_AD <- GET_AD(exv, Q$DATA$MTX, K = 5, NN_STATS = NULL)
colnames(ECHA_AD) <- paste0("Z-score(K=", 1:5, ")")
rownames(ECHA_AD) <- rownames(E1K)
write.table(ECHA_AD, "ECHA1K_GAD0.txt", sep = '\t', quote = FALSE)
#----------------------------------------------------------------------------------------------------------------




#------------------------------------------------------------------
#consensus calculations for 1) modeling sets and 2) for ECHA test set predictions

rootd <- paste0(odir,"\\sets\\models\\")
setwd(rootd)

cons_res <- NULL
names <- NULL
for (p1 in c("EPA", "GHS"))
{
  for (p2 in c("ANY", "IRR", "CORR"))
  {
    for (p3 in c("LO", "HI"))
    {
      for (p4 in c("MAIN", "MIX"))
      {
        cpatt <- paste("OCU", p1, p2, p3, p4, sep='_')
        mm<-list.files(rootd, pattern = paste0("^", cpatt,".*txt$" ), ignore.case = TRUE, full.names = FALSE)
        names <- c(names, cpatt)
        cons <- NULL
        for ( i in rev(mm) ) #rev to insure downsampled sets come last
        {
          w <- read.table( i, sep = '\t', header = TRUE, row.names = 1)
          #rownames(w) <- w$dataID
          cres <- CCR_ETC(w$CALC, w$EXP)
          
          #modeling set consensus
          pred0 <- w$CALC < cres[11] #use optimal break-point
          w[!pred0, "CALC"] <- 1
          w[pred0, "CALC"] <- 0
          if (is.null(cons))
          {
            cons <- w
            cons$N <- 1
          }
          else
          {
            rr <-rownames(w)
            aids <- rr[w$CALC == 1]
            cons[aids,"CALC"] <- cons[aids,"CALC"] + 1
            aids <- rr[w$EXP == 1]
            cons[aids,"EXP"] <- cons[aids,"EXP"] + 1 #for reality checking
            
            cons[rr, "N"] <- cons[rr, "N"] + 1 #model count in consensus
          }
        } #for i
        
        cons[,1] <- cons[,1] / cons[,3]
        cons[,2] <- cons[,2] / cons[,3]
        
        cres <- CCR_ETC(cons$CALC, cons$EXP)
        cons_res <- rbind(cons_res, cres)
        
        write.table(cons, paste0(rootd, "cons\\",cpatt, "_cons.txt"), sep = '\t', quote = FALSE)
      }
    }
  }
}

rownames(cons_res) <- names
colnames(cons_res) <- c("TOT", "INACTIVES", "ACTIVES",
                        "Spec.", "Sens.", "CCR", "Chi^2", "CohenKappa", "MutualInfo", "AUC", "bp")

write.table(cons_res[,c(1:6,10:11)], "ocutox_models_consensus.txt", sep = '\t', quote = FALSE)





#2)
#ECHA
E1K <- read.table("echa1k_main.txt", sep='\t', quote = '', comment.char = '')[,1:2]
echa_cons <- matrix(0, dim(E1K)[1], 24)
rownames(echa_cons) <- rownames(E1K)
colnames(echa_cons) <- names

for (p1 in c("EPA", "GHS"))
{
  for (p2 in c("ANY", "IRR", "CORR"))
  {
    for (p3 in c("LO", "HI"))
    {
      for (p4 in c("MAIN", "MIX"))
      {
        cpatt <- paste("OCU", p1, p2, p3, p4, sep='_')
        mm<-list.files(rootd, pattern = paste0("^", cpatt,".*txt$" ), ignore.case = TRUE, full.names = FALSE)
        
        
        for ( i in mm )
        {
          w <- read.table( i, sep = '\t', header = TRUE, row.names = 1)
          cres <- CCR_ETC(w$CALC, w$EXP) #to get optimal break-point
          
          ech <- read.table( paste0(rootd, "ECHA1K\\ECHA1K_", i), sep = '\t', header = TRUE)
          pred0 <- ech$pos < cres[11]
          echa_cons[!pred0,cpatt] <- echa_cons[!pred0,cpatt] + 1
        }
        
        echa_cons[, cpatt] <- echa_cons[, cpatt] / length(mm)
      }
    }
  }
}


write.table(echa_cons, "ocutox_ECHA1K_consensus_122020.txt", sep = '\t', quote = FALSE)
#--------------------------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------






#--------------------------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------
#important descriptors extraction from individual model results
#--------------------------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------

ddd <- paste0(odir, "\\sets\\models")
setwd(ddd)
vv <- list.files(ddd, "*.var")
topd <- matrix('na', length(vv), 10)
#f <- vv[1]
i <- 1
for (f in vv)
{
  z <- read.table(f, sep = '\t', header = TRUE, comment.char = '')
  cc <- dim(z)[2]
  ii <- sort(z[,cc], decreasing = TRUE, index.return = TRUE)$ix
  topd[i,] <- rownames(z)[ ii[1:10] ]
  i <- i + 1
}

rownames(topd) <- vv
colnames(topd) <- paste0("Top", 1:10)

write.table(topd, "qsar_epa_ghs_importantvars.txt", sep = '\t', quote = FALSE)