#xa.r - set of utilities for descriptor matrix preparation
#12.2020 - fix for nan arising in renorm functinos for redundant (constant) descriptors
#
#11.2019 - vec_renorm() added for individual vectors, 
#          coffs_0center() added for matrices, typical usage is coffs() then renorm() call with them as parameter
#
#

count_NA<-function(M, way)
{#counts NA values in rows or columns of the matrix M, way is 1 for rows, 2 for columns
  
  n <- dim(M)[way]
  cnt <- rep.int(0,n)
  for (v in 1:n)
  {
    if (way == 1)
    {
      I<-is.na(M[v,])
      cnt[v] <- length(M[v,I])
    }
    
    else
    {
      I<-is.na(M[,v])
      cnt[v] <- length(M[I,v])
    }
  }
  
  return(cnt)
}

coffs <- function(M)
{#returns min/max coefficients for columns in M matrix, this  can be used in renorm()
  
  CFS <- rbind( apply(M, 2, min), apply(M, 2, max) )
  colnames(CFS) <- colnames(M)
  return (CFS)
}

coffs_0center <- function(M)
{#returns mean / sd as  coefficients for columns in M matrix, this  can be used in renorm()
  
  CFS <- rbind( apply(M, 2, mean), apply(M, 2, sd) )
  colnames(CFS) <- colnames(M)
  return (CFS)
}

vec_renorm <- function(VEC, VLO = 0, VHI = 1, MOD = 0)
{
  #renormalizes vector to (VLO, VHI) by range-scaling (if MOD = 0), or, if MOD = 1, autoscales to VLO +/- VHI
  #can be used on matrices via apply(X = MTX, MARGIN = 2, FUN = vec_renorm, value_LO, value_HI, value_MOD)
  
  if (VLO >= VHI) return (NULL)
  
  if (MOD == 0) 
  {
    b <- min(VEC)
    a <- (VHI - VLO) / (max(VEC) - b)
    if (is.nan(a)) a <- 0
  } else
  {
    b <- mean(VEC)
    if (is.nan(b)) b <- 0
    
    a <- (VHI - VLO) / sd(VEC)
    if (is.nan(a)) a <- 0
  }
  
  return ( a*(VEC - b) + VLO )
}

renorm_reduce <- function(MAT, CFS)
{
  #normalizes values of MAT using min/max coefficients CFS (2 x NCOL matrix)
  #uses column names to align properly columns of MAT and CFS
  if ( is.null(CFS) ) return (CFS)
  
  CFSok <- colnames(CFS) %in% colnames(MAT)
  if (min(CFSok) == 0) return (NULL)
  
  
  #only continue if columns of CFS form subspace in MAT
  M <- MAT[,colnames(CFS)]
  
  s <- as.numeric( as.character( unlist(CFS[1,]) ) )
  v <- as.numeric( as.character( unlist(CFS[2,]) ) ) - s
  
  v[v == 0] <- 1 #fix for constant descriptors, these will not be rescaled
  
  tM <- t(M) - s
  return ( t( tM / v ) )
}

renorm <- function(MAT, CFS)
{
  #normalizes values of MAT using min/max coefficients CFS (2 x NCOL matrix)
  #columns in MAT and CFS are assumed to be aligned!!
  if ( is.null(CFS) ) return (CFS)
  
  s <- as.numeric( as.character( unlist(CFS[1,]) ) )
  v <- as.numeric( as.character( unlist(CFS[2,]) ) ) - s
  
  v[v == 0] <- 1 #fix for constant descriptors, these will not be rescaled
  
  tM <- t(MAT) - s
  return ( t( tM / v ) )
}

sink_XA<-function(FYL, ID1, ID2, ACT, MAT, LBL, CFS = NULL)
#creates tab-separated XA-format file FYL, with ID1, ID2, ACT columns and descriptor matrix MAT
#the descriptor labels are LBL (colnames cannot be used for that due to limitations on special characters)
#
{
  if (is.null(MAT) || is.null(FYL))
  {
    return -1
  }
  
  if (is.null(LBL))
  {
    LBL <- colnames(MAT)
  }
  
  if (is.null(ID1))
  {
    ID1 <- rownames(MAT)
  }
  
  if (is.null(ID2))
  {
    ID2 <- ID1
  }
  
  if (is.null(ACT))
  {
    ACT <- rep(-999, dim(MAT)[1])  
  }
  
  sink(FYL)
  cat(dim(MAT), sep='\t')
  cat('\n', append = TRUE)
  
  cat(as.character(LBL), sep = '\t', append = TRUE)
  cat('\n', append = TRUE)
  sink()
  
  write.table(cbind(ID1, ID2, ACT, MAT), file = FYL, append = TRUE,
              col.names = FALSE, row.names = FALSE, sep = "\t", quote = FALSE)
  
  if (!is.null(CFS)) 
    write.table(CFS, file=FYL, append=TRUE, col.names=FALSE, row.names=FALSE, sep="\t", quote=FALSE)
}


saveXA<-function(name, XX, AA=NULL, IDS=NULL, VLBL=NULL, CFS=NULL, newV=FALSE)
{
  ID1<-rownames(XX)
  
  if (is.null(IDS))
    ID2<-ID1 
  else 
    ID2<-IDS
  
  if (is.null(VLBL)) 
    LBL <-colnames(XX) 
  else 
    LBL <-as.vector(VLBL)
  
  if (newV == FALSE)
  {
    outxa <- paste(name, '.x', sep="")
    write.table(matrix(dim(XX),1,2), file=outxa, row.names=FALSE, col.names=FALSE, sep="\t", quote=FALSE, append=FALSE)
    write.table(matrix(LBL, 1, length(LBL)), file=outxa, row.names=FALSE, col.names=FALSE, sep="\t", quote=FALSE, append=TRUE)
    write.table(cbind(ID1, ID2, XX), file=outxa, row.names=FALSE, col.names=FALSE, sep="\t", quote=FALSE, append=TRUE)
    
    if (!is.null(CFS)) 
      write.table(CFS, file=outxa, row.names=FALSE, col.names=FALSE, sep="\t", quote=FALSE, append=TRUE)
    
    if (!is.null(AA)) 	#separate a-file
      write.table(cbind(ID1, AA), file=paste(name, '.a', sep=""), row.names=FALSE, col.names=FALSE, sep="\t", quote=FALSE, append=FALSE)
    
  } 
  else 
  {
    outxa <- paste(name, '.xa', sep="")
    write.table(matrix(dim(XX),1,2), file=outxa, row.names=FALSE, col.names=FALSE, sep="\t", quote=FALSE, append=FALSE)
    write.table(matrix(LBL, 1, length(LBL)), file=outxa, row.names=FALSE, col.names=FALSE, sep="\t", quote=FALSE, append=TRUE)
    if (is.null(AA)) 
    {
      A<-vector("integer", dim(XX)[1]);
      A[]<- -999
    }
    else A<-AA
    write.table(cbind(ID1, ID2, A, XX), file=outxa, row.names=FALSE, col.names=FALSE, sep="\t", quote=FALSE, append=TRUE)		
    
    if (!is.null(CFS)) 
      write.table(CFS, file=outxa, row.names=FALSE, col.names=FALSE, sep="\t", quote=FALSE, append=TRUE)
  }
}

loadXA<-function(base, newV=FALSE){
  if (newV == FALSE)
  {
    xfile <- paste(base, '.x', sep="")
    ds<-read.table(xfile, fill=TRUE, row.names=NULL, header=FALSE,comment.char="",quote="")
    Ncpd<-as.numeric(as.character(ds[1, "V1"]))
    Ndes<-as.numeric(as.character(ds[1, "V2"]))
    dsheader<-as.vector(unlist(ds[2, 1:Ndes]))
    name <- as.vector(unlist(ds[3:(2+Ncpd), 2]))
    
    dsdata<-as.numeric(as.matrix(ds[3:(2+Ncpd), -c(1,2)])) 
    dim(dsdata) <- c(length(name), length(dsheader))
    colnames(dsdata)<-dsheader
    rownames(dsdata)<-name
    
    ifcoff<-FALSE
    if (nrow(ds) == Ncpd + 4) # this x file has coefficients
    {
      ifcoff<-TRUE
      coff <- ds[ c(nrow(ds)-1, nrow(ds)), 1:Ndes]
      names(coff) = dsheader
    }
    
    afile <- paste(base, '.a', sep="")
    if (file.exists(afile))
    {
      dsa<-read.table(afile,row.names=NULL,col.names=c("name","activity"),
                      header=F,comment.char="",quote="")	
      if (ifcoff)
      {
        list(x=as.data.frame(dsdata), desName=dsheader, a=dsa$activity,cpdName=as.vector(dsa$name), coff=coff)
      } else 
      {
        list(x=as.data.frame(dsdata), desName=dsheader, a=dsa$activity,cpdName=as.vector(dsa$name))		
      }
    } else 
    {
      if (ifcoff)
      {
        list(x=as.data.frame(dsdata), desName=dsheader, cpdName=name, coff=coff)
      } else
      {
        list(x=as.data.frame(dsdata), desName=dsheader, cpdName=name)
      }
    }
  } else 
  {
    xafile <- paste(base, '.xa', sep="")
    ds<-read.table(xafile, fill=TRUE, row.names=NULL, header=FALSE,comment.char="",quote="")
    Ncpd<-as.numeric(as.character(ds[1, "V1"]))
    Ndes<-as.numeric(as.character(ds[1, "V2"]))
    dsheader<-as.vector(unlist(ds[2, 1:Ndes]))
    name <- as.vector(unlist(ds[3:(2+Ncpd), 2]))
    
    dsdata<-as.numeric(as.matrix(ds[3:(2+Ncpd), -(1:3)])) 
    dim(dsdata) <- c(length(name), length(dsheader))
    colnames(dsdata)<-dsheader
    rownames(dsdata)<-name
    
    activity <- as.character(unlist(ds[3:(2+Ncpd), 3]))
    
    if (nrow(ds) == Ncpd + 4) #this xa file has coefficients
    {
      coff <- ds[ c(nrow(ds)-1, nrow(ds)), 1:Ndes]
      names(coff) = dsheader
      list(x=as.data.frame(dsdata), desName=dsheader, a=activity,cpdName=name, coff=coff)
    } else
    {
      list(x=as.data.frame(dsdata), desName=dsheader, a=activity,cpdName=name)
    }
  }
}

txt2xa<-function(FILE, TYPE = 0, UID=NULL, ACT=NULL, M=NULL)
# converts descriptor output .txt files into .xa descriptor matrix files

#FILE: file name including extension, has to be tab-separated
#TYPE: 0 - Dragon descriptors, 1 - MOE descriptors
#UID - column name or position with unique sample ids (1..n if NULL)
#ACT - column name or position with activity values, if NULL, fake "-999" values used
#M: 	number of descriptors to keep (M rightmost columns),
#	if NULL - all are used (then MOE should have no extra columns!)
#
#Examples:
#> txt2xa('NCC_std_drg.txt') #for default conversion of Dragon file
#> txt2xa('NCC_std_drg.txt', UID=2) #same but IDs are from second column
#> txt2xa('NCC_std_moe.txt', TYPE=1, UID=2, M=186), #for MOE file conversion
{
  xM <- 1;				#non-descriptor dimensions
  if (is.null(UID))	UID<-1	#use first column for ids
  
  if (TYPE == 0)
  {	#Dragon
    XX<-read.table(FILE, header = FALSE, sep="\t", row.names=NULL, skip=2, comment.char="", quote="")
    xM <- xM + 1;
  }	
  else
  {	#MOE
    XX<-read.table(FILE, header = FALSE, sep="\t", row.names=NULL, comment.char="", quote="")
  }
  
  DSCR<-XX[-1,]
  colnames(DSCR)<-as.vector(unlist(XX[1,]))
  vid<-gsub('[\\/\\+\\s]', '_', DSCR[,UID], perl=TRUE)		#fix blanks in the names
  N<-dim(DSCR)[1]
  if (is.null(ACT))	
  {
    vact<- 1:N 
    vact[1:N] <- -999
  }
  else
  {
    xM <- xM + 1;
    vact<-DSCR[,ACT]
  }
  
  if (is.null(M)) 	M<- (dim(XX)[2] - xM)
  tM<-dim(XX)[2] - M
  MX<-DSCR[,-1:-tM]
  
  rownames(MX)<-1:N
  vdescr<-colnames(MX)
  
  outxa<-gsub('\\.txt$', '', FILE)
  saveXA(outxa, MX, AA=vact, IDS=vid, VLBL=vdescr, newV=TRUE)
}




# R function to convert .txt files into .xa descriptor matrix files
# relies on saveXA.R for conversion

#--------------------------------------------------
#FILE: file name including extension, has to be tab-separated
#TYPE: 0 - Dragon descriptors, 1 - MOE descriptors
#UID - column name or position with unique sample ids (1..n if NULL)
#ACT - column name or position with activity values, if NULL, fake "-999" values used
#M: 	number of descriptors to keep (M rightmost columns),
#	if NULL - all are used (then MOE should have no extra columns!)
#
#
#Examples:
#> txt2xa('NCC_std_drg.txt') #for default conversion of Dragon file
#> txt2xa('NCC_std_drg.txt', UID=2) #same but IDs are from second column
#> txt2xa('NCC_std_moe.txt', TYPE=1, UID=2, M=186), #for MOE file conversion
#--------------------------------------------------
txt2xa<-function(FILE, TYPE = 0, UID=NULL, ACT=NULL, M=NULL)
{
  xM <- 1;				#non-descriptor dimensions
  if (is.null(UID))	UID<-1	#use first column for ids
  
  if (TYPE == 0)
  {	#Dragon
    XX<-read.table(FILE, header = FALSE, sep="\t", row.names=NULL, skip=2, comment.char="", quote="")
    xM <- xM + 1;
  }	
  else
  {	#MOE
    XX<-read.table(FILE, header = FALSE, sep="\t", row.names=NULL, comment.char="", quote="")
  }
  
  DSCR<-XX[-1,]
  colnames(DSCR)<-as.vector(unlist(XX[1,]))
  vid<-gsub('[\\/\\+\\s]', '_', DSCR[,UID], perl=TRUE)		#fix blanks in the names
  N<-dim(DSCR)[1]
  if (is.null(ACT))	
  {
    vact<- 1:N 
    vact[1:N] <- -999
  }
  else
  {
    xM <- xM + 1;
    vact<-DSCR[,ACT]
  }
  
  if (is.null(M)) 	M<- (dim(XX)[2] - xM)
  tM<-dim(XX)[2] - M
  MX<-DSCR[,-1:-tM]
  
  rownames(MX)<-1:N
  vdescr<-colnames(MX)
  
  outxa<-gsub('\\.txt$', '', FILE)
  saveXA(outxa, MX, AA=vact, IDS=vid, VLBL=vdescr, newV=TRUE)
}
